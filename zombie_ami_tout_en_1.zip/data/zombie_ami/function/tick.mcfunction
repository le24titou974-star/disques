# Les joueurs sans equipe rejoignent l'equipe amie (les mobs de la meme equipe ne s'attaquent pas)
team join ami_team @a[team=]
# Les zombies amis rejoignent l'equipe
team join ami_team @e[type=minecraft:zombie,tag=zombie_ami,team=]
# Les golems (fer et neige) rejoignent aussi l'equipe : ils ne frappent plus le zombie ami
team join ami_team @e[type=#zombie_ami:golems,team=]
# Logique de chaque zombie ami
execute as @e[type=minecraft:zombie,tag=zombie_ami] at @s run function zombie_ami:ami
