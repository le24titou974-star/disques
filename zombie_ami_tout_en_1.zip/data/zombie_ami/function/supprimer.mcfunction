tp @e[type=minecraft:zombie,tag=zombie_ami] ~ -1000 ~
kill @e[type=minecraft:zombie,tag=zombie_ami]
