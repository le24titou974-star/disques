scoreboard players add @s ami_cd 1

# --- Combat : un ennemi dans les 12 blocs ---
execute if entity @e[type=#zombie_ami:ennemis,tag=!zombie_ami,team=!ami_team,distance=..12] run function zombie_ami:combat

# --- Suivi du joueur (si aucun ennemi proche) ---
# Trop loin : il se teleporte pres du joueur
execute unless entity @e[type=#zombie_ami:ennemis,tag=!zombie_ami,team=!ami_team,distance=..12] if entity @p[distance=20..80] run tp @s @p
# Moyennement loin : il glisse vers le joueur (sans traverser les blocs)
execute unless entity @e[type=#zombie_ami:ennemis,tag=!zombie_ami,team=!ami_team,distance=..12] if entity @p[distance=5..20] facing entity @p feet if block ^ ^ ^0.6 minecraft:air if block ^ ^1 ^0.6 minecraft:air run tp @s ^ ^ ^0.14
