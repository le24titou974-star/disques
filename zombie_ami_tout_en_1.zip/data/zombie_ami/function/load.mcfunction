scoreboard objectives add ami_cd dummy
team add ami_team
team modify ami_team friendlyFire false
team modify ami_team seeFriendlyInvisibles true
tellraw @a {"text":"[Zombie Ami] charge ! Tape /function zombie_ami:invoquer ou /function zombie_ami:oeuf","color":"green"}
