scoreboard objectives add disques_rand dummy
