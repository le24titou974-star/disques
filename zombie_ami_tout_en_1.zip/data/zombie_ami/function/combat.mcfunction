# Se rapproche de l'ennemi le plus proche
execute facing entity @e[type=#zombie_ami:ennemis,tag=!zombie_ami,team=!ami_team,distance=..12,sort=nearest,limit=1] feet if block ^ ^ ^0.6 #minecraft:replaceable if block ^ ^1 ^0.6 #minecraft:replaceable unless entity @e[type=#zombie_ami:ennemis,tag=!zombie_ami,team=!ami_team,distance=..2.2] run tp @s ^ ^ ^0.16

# Frappe toutes les 15 ticks l'ennemi a portee
execute if score @s ami_cd matches 15.. if entity @e[type=#zombie_ami:ennemis,tag=!zombie_ami,team=!ami_team,distance=..2.2] run function zombie_ami:frappe
