advancement revoke @s only disques:maire_clic
execute store result score #r disques_rand run random value 1..4
execute if score #r disques_rand matches 1 run tellraw @s [{"text": "[Maire] ", "color": "gold"}, {"text": "Bienvenue dans notre beau village, citoyen !", "color": "white"}]
execute if score #r disques_rand matches 2 run tellraw @s [{"text": "[Maire] ", "color": "gold"}, {"text": "Un disque rare, rien que pour vous. Cinq émeraudes, c'est donné !", "color": "white"}]
execute if score #r disques_rand matches 3 run tellraw @s [{"text": "[Maire] ", "color": "gold"}, {"text": "Les affaires vont bien... enfin, quand les zombies nous laissent tranquilles.", "color": "white"}]
execute if score #r disques_rand matches 4 run tellraw @s [{"text": "[Maire] ", "color": "gold"}, {"text": "Je suis le maire, et ce costume est fait sur mesure.", "color": "white"}]
