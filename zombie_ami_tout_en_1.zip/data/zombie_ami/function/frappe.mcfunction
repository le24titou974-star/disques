scoreboard players set @s ami_cd 0
tag @s add ami_attaquant
execute as @e[type=#zombie_ami:ennemis,tag=!zombie_ami,team=!ami_team,distance=..2.2,sort=nearest,limit=1] at @s run particle minecraft:crit ~ ~1 ~ 0.3 0.3 0.3 0.2 8
execute as @e[type=#zombie_ami:ennemis,tag=!zombie_ami,team=!ami_team,distance=..2.2,sort=nearest,limit=1] run damage @s 6 minecraft:mob_attack by @e[type=minecraft:zombie,tag=ami_attaquant,limit=1]
tag @s remove ami_attaquant
playsound minecraft:entity.player.attack.sweep hostile @a ~ ~ ~ 1 1
